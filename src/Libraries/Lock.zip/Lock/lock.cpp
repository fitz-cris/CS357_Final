//Cris Fitzgerald Spring 2020 CS 357
#include "Arduino.h"
#include "Lock.h"

lock::lock()
  {
    state = false;
	for (int i=0;i < 4;i++)
    {
      this->combination[i] = -1;
    }
  }
int lock::resetCombination(int newCombination[4])
  {
     for (int i=0;i < 4;i++)
    {
      this->combination[i] = newCombination[i];
    }
  }
int lock::testCombination(int givenCombination[4])
  {
    int unlock = 1; 
    for (int i=0;i < 4;i++)
    {
      if(givenCombination[i] != this->combination[i])
      {
        unlock = -1;
      }
    }
    return unlock;
  }
bool lock::getState()
  {
	return this->state;
  }
int lock::setState(bool newState)
  {
	this->state = newState;
  }



