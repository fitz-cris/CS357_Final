//Cris Fitzgerald Spring 2020 CS 357
#ifndef Lock_h
#define Lock_h

#include "arduino.h"

class lock
{
  public:
  lock();
  int resetCombination(int newCombination[4]);  //sets new combination
  int testCombination(int givenCombination[4]); //tests a given combination vs the locks private combo
  bool getState(); 								//returns 0 if closed, 1 if open
  int setState(bool newState);					//sests state

  private:
  bool state; //false is locked, true is open
  int combination[4];
};

#endif
